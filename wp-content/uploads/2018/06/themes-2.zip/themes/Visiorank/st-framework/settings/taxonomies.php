<?php
// register_cuztom_taxonomy
//register_cuztom_taxonomy('theme_categories','theme');